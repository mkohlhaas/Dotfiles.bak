package main

import "github.com/kkc/safari-books-downloader/internalmain"

func main() {
	internalmain.Main()
}
